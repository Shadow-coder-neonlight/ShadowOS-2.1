# Box-Function-4.0-by-Kvc
Prints a box, with different box styles.(New Styles+Fast Display)
